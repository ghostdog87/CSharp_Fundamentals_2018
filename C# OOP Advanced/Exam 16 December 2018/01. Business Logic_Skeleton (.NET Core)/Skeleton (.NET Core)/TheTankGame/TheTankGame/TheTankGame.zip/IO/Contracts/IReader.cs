﻿namespace TheTankGame.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
