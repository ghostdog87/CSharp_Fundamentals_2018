﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Solid.Layouts.Contracts
{
    public interface ILayout
    {
        string Format { get; }
    }
}
