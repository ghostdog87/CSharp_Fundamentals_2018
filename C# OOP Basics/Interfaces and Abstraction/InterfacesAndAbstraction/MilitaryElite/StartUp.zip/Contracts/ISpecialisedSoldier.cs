﻿using MilitaryEliteV1_2.EnumM;
using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryEliteV1_2.Contracts
{
    public interface ISpecialisedSoldier
    {
        Corps Corps { get; }
    }
}
