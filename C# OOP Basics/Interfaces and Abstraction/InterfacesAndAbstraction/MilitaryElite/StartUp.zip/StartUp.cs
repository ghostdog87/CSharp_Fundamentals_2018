﻿using MilitaryEliteV1_2.Core;
using System;

namespace MilitaryEliteV1_2
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
